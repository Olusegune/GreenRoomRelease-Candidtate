Portable: run 'Greenroom Local.exe' from any folder (needs Microsoft Edge WebView2, built into Windows 11). Not code-signed, so Windows may show a SmartScreen warning.
